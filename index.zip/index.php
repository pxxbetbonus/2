<!DOCTYPE html>
<html lang="vi">
	<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-compatible" content="IE=edge">
        <meta name="viewport"content="width=devica-width,initial-scale=1.0">
        <link rel="stylesheet" href="http://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <title>pxxbet.com</title>
	</head>
	<body>
		<div id="container">

			<div id="menu">
				<ul>
					<li><a href="https://pxxbet.com/">JOGO</a></li>
					<li><a href="https://t.me/PXXbetcom/239">bônus R$9</a></li>
					<li><a href="https://t.me/PXXbetcom/259">giro da sorte</a></li>
					<li><a href="https://pxxbet.com/gameList?flag=208">jogo bônus</a></li>
					<li><a href="https://t.me/BONUSPXXBET">pxxbet grupo</a></li>
				</ul>
			</div><!--END #menu-->

			<div id="content">

				<div id="header">
					<div id="logo"><img src="https://pxxbet.com/img/logo.a936e362.png" alt="PXXBETBONUS" /></div>
					<div id="slogan"><h3>Faça login todos os dias e ganhe recompensas de R$ 2 a R$ 4</h3>
                                      <h3>Receba recompensas gratuitamente, não há necessidade de depositar para ainda receber recompensas</h3></div>
				</div><!--#header-->

				<div class="call-to-action">
					<h3>Por favor insira o telefone válido conforme o</h3>
                    <h3>exemplo: +55 (11) 99999-9999.</h3>
					
                    <img src="https://i.pinimg.com/736x/30/89/5c/30895cbae761afabff6fbbf4ead96650.jpg" alt="URL" />

                    <div class="row">
                        <div class="col-6 offset-md-3">
                          <form id="form_reg" class="bg-light p-4 my-3" action="reg.php"method="post">
                              <div class="form-group">
                                
                                <input type="tel" class="form-control" id="phonenumber" name="phonenumber"placeholder="Número de telefone"pattern="(55)[0-9]{11}"title="Insira 13 números com 55 no início do número de telefone"required>

                            </div>
                            <input type="submit" class="btn btn-primary btn-block mt-4" name="btn-reg" value="enviar">
                          </form>

				</div><!--.call-to-action-->


				<div class="row">
					
					 <div id="box1" class="col">

						<p>Distribuiremos recompensas das 20h00 às 22h00 todos os dias</p> 

                        <p>Para receber a recompensa, preencha seu número de telefone corretamente. e evite preencher muitas vezes</p>
                            
					</div>
                    
				</div><!--.call-to-action-->

			</div><!--#content-->

			<div id="footer">
				<p>PXXBETBONUS &copy; 2024 - Seguro contra perdas para clientes</p>
			</div><!--#footer-->

		</div><!--#container-->
	</body>
</html>

<style>

* {
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
}
body{
    background: url('https://i.pinimg.com/736x/29/e9/de/29e9def3817041900f702dc8b140fef8.jpg');
    background-size: cover;
    background-position-y: -100px;
    font-size: -100px;
}
body {
    font-family: Georgia, serif;
    font-size: 16px;
    line-height: 1.254em;
    margin: 0;
    padding: 0;
}
a {
    text-decoration: none;
    color: #020202;
}
a:hover,
a:visited {
    color: #000000;
}



/*==Style cơ bản cho website==*/
* {
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
}
body {
    font-family: Helvetica,Arial,sans-serif;
    font-size: 18px;
    line-height: 1.254em;
    margin: 0;
    padding: 0;
}
a {
    text-decoration: none;
    color: #ffffff;
}
a:hover,
a:visited {
    color: #ffffff;
}


/*==Lên khung cho website==*/
#container {
    padding-left: 150px;
    position: relative;
    left: 0;
    width: 100%;
}
#menu {
    position: fixed;
    height: 100%;
    background-color: #18135a;
    width: 150px;
    left: 0;
}

/*==Trang trí menu==*/
#menu ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
}
#menu ul li {
    line-height: 2.9em;
    height: 2.9em;
}
#menu li a {
    display: block;
    color: #5580f5;
    padding: 0 1em;
    border-bottom: 1px solid #53e2b7;
}
#menu li:hover {
    background-color: #e60000;
}

/*==Trang trí khung content==*/
#content {
  padding: 1em 8em;
}
#header,
.call-to-action {
    text-align: center;
}

/*==Trang trí header của content==*/
#header{}
#slogan {
    color: #E6E6E6;
    font-size: 1em;
}

/*==khung hình==*/
.call-to-action {
    padding: 3em 20%;
    background: #9ecf8f;
    border: 3px solid#E8E8E8;
}

/*==Chia cột phần content==*/
.row {
    overflow: auto;
    margin: 1em auto;
}
.row .col {
    float: none;
    width: 100%;
    margin-right: 2.99%;
}
.row .col:last-child {
    float: right;
    margin-right: 0;
}
/* Style cho ảnh */
.row .col img {
    float: none;
    margin-right: 1em;
}

/*==Footer==*/
#footer {
  font-size: 85%;
  border-top: 1px solid #E6E6E6;
  color: #ffffff;
  padding: 1em 3em;
}

</style>